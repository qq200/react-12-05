import React, {Component} from 'react'
import axios from 'axios'
const KEY='4e3acf73c902c0c63d20650f37455fbe';
const URL=`http://data.fixer.io/api/latest?access_key=${KEY}`;

class Currency extends Component{
    constructor(){
        super();
        this.state={rates:{}};
        /// ACAsa component DIdMount
        var rate;
        var _this=this;
        axios.get(URL)
            .then(function(response){
                let code=_this.props.match.params.code;
               
            //    rate=response.data.rates[code.toUpperCase()]
                // console.log(rate);
                _this.setState({rates: response.data.rates})
                });
    }
    render(){
        let code=this.props.match.params.code;
        // console.log(this.props)
        
        
        return(
            <div> Info for {code} {this.state.rates[code.toUpperCase()]}</div>
        )
    }
}
export default Currency