import React, {Component} from 'react'

class Contact extends Component{
    render(){

        
        return(
            <div> 022-44-55-99 </div>
        )
    }
}
export default Contact