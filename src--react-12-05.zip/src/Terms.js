import React, {Component} from 'react'

class Terms extends Component{
    render(){

        // console.log(this.props)

        return(
            <div> Terms of contract </div>
        )
    }
}
export default Terms