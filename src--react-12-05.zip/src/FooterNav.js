import React, {Component} from 'react'
import {BrowserRouter as Router, Link, Route} from 'react-router-dom'
import Contact from './Contact.js'
import Terms from './Terms.js'

class FooterNav extends Component{ 
    render(){
        return(
            <Router>
            <nav>
                <Link to="/Contact"> Contact</Link>
                <br/>
                <Link to="/Terms"> Terms</Link>
                <br/>
                
            </nav>
            <hr/>
            <Route path="/Contact"  component ={Contact}/>
            <Route path="/Terms"  component ={Terms}/>            
            <hr/>
            </Router>
            
        )
    }
}
export default FooterNav